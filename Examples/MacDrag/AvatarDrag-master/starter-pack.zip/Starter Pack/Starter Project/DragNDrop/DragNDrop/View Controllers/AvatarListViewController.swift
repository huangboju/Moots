//
//  AvatarListViewController.swift
//  DragNDrop
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 Appcoda. All rights reserved.
//

import Cocoa

class AvatarListViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
