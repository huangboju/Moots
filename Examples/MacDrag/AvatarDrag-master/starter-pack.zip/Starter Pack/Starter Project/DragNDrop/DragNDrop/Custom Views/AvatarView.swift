//
//  AvatarView.swift
//  DragNDrop
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 Appcoda. All rights reserved.
//

import Cocoa

class AvatarView: NSView {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var imageView: NSImageView!
    
    @IBOutlet weak var quoteLabel: NSTextField!

    
    // MARK: - Properties
    
    var avatarInfo = AvatarInfo()
    
    
    // MARK: - Init
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Enable layer in self view.
        self.wantsLayer = true
        
        // Enable layer in the image view and
        // set corner radius and border.
        imageView.wantsLayer = true
        imageView.layer?.cornerRadius = 120.0
        imageView.layer?.borderWidth = 5.0
        imageView.layer?.borderColor = NSColor.lightGray.cgColor
    }
    
    
    // MARK: - Methods Implementation
    
    
    
}
